/// <reference types="vite/client" />

interface VoiceflowChat {
  open(): void;
  sendMessage(message: string): void;
}

interface Window {
  voiceflow: {
    chat: VoiceflowChat;
  };
}