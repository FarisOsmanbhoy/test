import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  MessageSquare, 
  Calendar, 
  ArrowRight, 
  Hammer,
  Mail,
  Linkedin,
  Phone
} from 'lucide-react';
import { Link } from 'react-router-dom';

const BackendModules = [
  'Email Responder Generator (GPT)',
  'Role-Based GPT Routing',
  'Smart Form → Contract Generator',
  'GPT Summary Writer',
  'Self-learning Logger',
  'Whisper Voice-to-Text Summarizer',
  'Task Log → PM/CRM Update',
  'Lead Form → CRM or Airtable',
  'Event Trigger → Slack/Email Notify + Archive',
  'Contract Generator → Send + Tag',
  'Client Submission → Internal Tracker',
  'Receipt Parser → Expense Log',
  'File Upload → Drive Organizer',
  'Resume → Candidate Tracker',
  'Daily Input → CRM Digest',
  'Feedback Collector + Sentiment Scorer',
  'CRM Auto-Updater',
  'Document Upload → GPT Summary',
  'LinkedIn Engagement Tracker',
  'Weekly CRM Data Analysis → GPT Suggestions',
  'Notion or Airtable Archiver',
  'PDF to Excel Parser',
  'Auto-fill & Send Proposal PDF',
  'Daily Summary Generator',
  'Smart Status Tracker'
];

const FrontendModules = [
  {
    id: 'F1',
    name: 'AI Assistant System',
    description: 'Smart chatbot that handles Q&A, user guidance, and intelligent routing.'
  },
  {
    id: 'F2',
    name: 'Lead Capture & Booking',
    description: 'Custom forms, intake flows, and direct calendar scheduling.'
  },
  {
    id: 'F3',
    name: 'CRM / Internal Data Capture',
    description: 'Internal task inputs, feedback collection, and smart system logging.'
  },
  {
    id: 'F4',
    name: 'Quote / Proposal Builder',
    description: 'Structured inputs flow into smart pricing engines and downloadable client-ready proposals.'
  }
];

const NavBar = () => {
  const [isScrolled, setIsScrolled] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-black/90 backdrop-blur-sm' : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="text-xl font-bold flex items-center gap-2">
            <Hammer className="w-6 h-6 text-orange-500" />
            <span>Forge Protocol</span>
          </Link>
          <div className="hidden md:flex space-x-1">
            <Link to="/" className="nav-item">Home</Link>
            <a href="#frontend" className="nav-item">Frontend</a>
            <a href="#backend" className="nav-item">Backend</a>
            <a href="#hybrid" className="nav-item">Hybrid</a>
          </div>
        </div>
      </div>
    </nav>
  );
};

const CTASection = () => {
  const handleTalkToSystem = () => {
    if (window.voiceflow?.chat?.open) {
      window.voiceflow.chat.open();
      setTimeout(() => {
        if (window.voiceflow?.chat?.sendMessage) {
          window.voiceflow.chat.sendMessage('talk_to_system');
        }
      }, 1000);
    }
  };

  const handleScheduleCall = () => {
    if (window.voiceflow?.chat?.open) {
      window.voiceflow.chat.open();
      setTimeout(() => {
        if (window.voiceflow?.chat?.sendMessage) {
          window.voiceflow.chat.sendMessage('schedule_call');
        }
      }, 1000);
    }
  };

  return (
    <section className="bg-black py-16">
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <motion.button
            onClick={handleTalkToSystem}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-full 
            font-semibold transition-all duration-300 flex items-center gap-2 hover:shadow-glow"
          >
            <MessageSquare className="w-5 h-5" />
            Talk to the System
          </motion.button>
          <motion.button
            onClick={handleScheduleCall}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 bg-transparent border-2 border-blue-500/30 text-white 
            rounded-full font-semibold transition-all duration-300 flex items-center gap-2 hover:shadow-glow"
          >
            <Calendar className="w-5 h-5" />
            Schedule a Call
          </motion.button>
        </div>
      </div>
      <div className="container mx-auto px-4 mt-8">
        <div className="h-px bg-white/15" />
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="footer-gradient py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-12 items-start mb-12">
            <div>
              <h3 className="text-xl font-bold mb-4">Connect With Us</h3>
              <div className="flex flex-col gap-4">
                <Link to="/" className="footer-link">About</Link>
                <Link to="/" className="footer-link">ForgeOS</Link>
                <Link to="/" className="footer-link">Case Studies</Link>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-4">Quick Links</h3>
              <div className="grid gap-2">
                <Link to="/" className="footer-link">Modules</Link>
                <Link to="/" className="footer-link">Scenario Builder</Link>
                <Link to="/" className="footer-link">DQB</Link>
                <Link to="/" className="footer-link">Contact</Link>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-4">Contact</h3>
              <div className="space-y-4">
                <div className="flex flex-col gap-2">
                  <a 
                    href="https://www.linkedin.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="footer-contact-link"
                  >
                    <Linkedin className="w-5 h-5" />
                    LinkedIn
                  </a>
                  <a 
                    href="mailto:contact@forgeprotocol.com"
                    className="footer-contact-link"
                  >
                    <Mail className="w-5 h-5" />
                    Email
                  </a>
                </div>

                <div className="text-sm text-gray-400">
                  <p className="font-semibold mb-2">Global Lines:</p>
                  <div className="space-y-2">
                    <p>USA (Call Only): <a href="tel:+18322193227" className="hover:text-white">+1 832 219 3227</a></p>
                    <p>
                      UK/EU: 
                      <a href="tel:+447436352521" className="hover:text-white ml-1">+44 7436 352521</a>
                      <span className="mx-1">|</span>
                      <a href="https://wa.me/+447436352521" target="_blank" rel="noopener noreferrer" className="hover:text-white">WhatsApp</a>
                    </p>
                    <p>
                      Singapore (WhatsApp Only): 
                      <a href="https://wa.me/+6597942604" target="_blank" rel="noopener noreferrer" className="hover:text-white ml-1">+65 9794 2604</a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <hr className="border-white/15 mb-8" />
            <p className="text-gray-400">© Forge Protocol 2025</p>
            <div className="flex justify-center gap-4 mt-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a>
              <span className="text-gray-600">•</span>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Terms & Conditions</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

const ExploreModules = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white relative">
      {/* Background Effects */}
      <div className="absolute inset-0 hero-grid" />
      <div className="absolute inset-0 hero-circuit" />
      <div className="absolute inset-0 hero-glow" />
      
      <NavBar />
      
      <div className="relative">
        <div className="container mx-auto px-4 py-24">
          <div className="max-w-6xl mx-auto">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-5xl font-bold mb-6 text-center hero-font glow pt-16"
            >
              Explore the Forge OS Modules
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-xl text-gray-300 text-center mb-16 max-w-4xl mx-auto"
            >
              Built to replace chaos with clarity — modular systems designed for real operational scale.
            </motion.p>

            <div className="divider mb-16" />

            {/* Frontend Modules */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="mb-16" 
              id="frontend"
            >
              <h2 className="text-3xl font-bold mb-8">Frontend Modules</h2>
              <div className="grid gap-8">
                {FrontendModules.map((module) => (
                  <motion.div
                    key={module.id}
                    whileHover={{ scale: 1.02 }}
                    className="p-6 rounded-lg border border-blue-500/20 hover:border-blue-500/40 
                    bg-black/30 backdrop-blur-sm relative group"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-blue-500/5 
                    group-hover:from-blue-500/10 group-hover:to-blue-500/10 rounded-lg transition-all duration-300" />
                    <h3 className="text-xl font-semibold mb-2 relative">
                      {module.id} — {module.name}
                    </h3>
                    <p className="text-gray-300 relative">{module.description}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <div className="divider mb-16" />

            {/* Backend Modules */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="mb-16" 
              id="backend"
            >
              <h2 className="text-3xl font-bold mb-8">Backend Modules</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {BackendModules.map((module, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    className="p-4 rounded-lg border border-orange-500/20 hover:border-orange-500/40 
                    bg-black/30 backdrop-blur-sm relative group"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-orange-500/5 
                    group-hover:from-orange-500/10 group-hover:to-orange-500/10 rounded-lg transition-all duration-300" />
                    <p className="text-gray-300 relative">B{index + 1} — {module}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <div className="divider mb-16" />

            {/* Hybrid Systems */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="mb-16" 
              id="hybrid"
            >
              <motion.div
                whileHover={{ scale: 1.02 }}
                className="p-8 rounded-xl border border-purple-500/20 hover:border-purple-500/40 
                bg-black/30 backdrop-blur-sm relative group"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-purple-500/5 
                group-hover:from-purple-500/10 group-hover:to-purple-500/10 rounded-xl transition-all duration-300" />
                <h2 className="text-3xl font-bold mb-4 relative">Hybrid Systems</h2>
                <p className="text-xl text-gray-300 mb-6 relative">
                  When Frontend and Backend modules combine, we create intelligent custom systems designed for real-world operations.
                </p>
                <ul className="list-disc list-inside text-gray-300 space-y-2 mb-8 relative">
                  <li>Combine 4+ backend modules</li>
                  <li>Mix frontend flows with backend logic</li>
                  <li>Adapt dynamically to your business needs</li>
                </ul>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>

      <CTASection />
      <Footer />
    </div>
  );
};

export default ExploreModules;