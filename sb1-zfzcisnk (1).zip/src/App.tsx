import React, { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Link } from 'react-router-dom';
import { 
  Hammer, 
  Cpu, 
  Zap, 
  ChevronRight, 
  MessageSquare, 
  Calendar,
  ChevronLeft,
  Users,
  FileText,
  Brain,
  ArrowRight,
  Github,
  Twitter,
  Linkedin,
  ChevronDown,
  PhoneCall,
  FormInput,
  Calculator,
  Router,
  Bot,
  Workflow,
  Sparkles,
  CloudLightning as Lightning,
  ArrowUpRight,
  UserCheck,
  Building2,
  Inbox,
  MessageCircle,
  CalendarCheck,
  FileInput,
  GitFork,
  Bell,
  Lightbulb,
  Code,
  Rocket,
  Shield,
  Mail,
  Phone
} from 'lucide-react';

const caseStudies = [
  {
    title: "Enterprise Sales Automation",
    description: "Automated lead qualification, meeting scheduling, and follow-up sequences for a B2B SaaS company, reducing sales cycle by 45%.",
    icon: Building2
  },
  {
    title: "Client Onboarding System",
    description: "Built an intelligent onboarding flow for a consulting firm, handling document collection, task routing, and client communication automatically.",
    icon: UserCheck
  },
  {
    title: "Service Delivery Platform",
    description: "Created a smart service delivery system for a digital agency, automating project updates, resource allocation, and client reporting.",
    icon: Rocket
  }
];

const forgeModules = [
  {
    title: "Smart AI Chatbot",
    description: "Engages users in natural dialogue, routes queries, and responds instantly.",
    tag: "Frontend",
    icon: MessageCircle,
  },
  {
    title: "Lead Capture & Booking Flow",
    description: "Collects lead data with forms, then routes directly to calendar availability.",
    tag: "Frontend",
    icon: CalendarCheck,
  },
  {
    title: "Smart Quote Builder",
    description: "Dynamic pricing tools based on user inputs, product tiers, or service bundles.",
    tag: "Frontend",
    icon: Calculator,
  },
  {
    title: "Internal Task Routing",
    description: "Assigns tasks based on triggers, tags, or custom rules — reducing ops bottlenecks.",
    tag: "Backend",
    icon: GitFork,
  },
  {
    title: "Follow-Up Automation Engine",
    description: "Sends CRM sequences and reminders based on timing or engagement.",
    tag: "Backend",
    icon: Calendar,
  },
  {
    title: "Data Sync + CRM Bridge",
    description: "Connects Airtable, Excel, or CRMs — enabling live 2-way syncing.",
    tag: "Backend",
    icon: Router,
  },
  {
    title: "File to CRM Flow",
    description: "Extracts data from PDFs/uploads and maps it into CRM pipelines.",
    tag: "Hybrid",
    icon: FileInput,
  },
  {
    title: "AI Summary & Insights Engine",
    description: "Creates real-time summaries and insights from chats, docs, or inputs.",
    tag: "Hybrid",
    icon: Brain,
  },
  {
    title: "Custom Alerts & Notifications",
    description: "Sets up smart alerts via Slack, email, or app triggers.",
    tag: "Hybrid",
    icon: Bell,
  },
  {
    title: "Scenario Intelligence System",
    description: "Ties multiple modules into a personalized, dynamic workflow engine.",
    tag: "Hybrid",
    icon: Lightbulb,
  },
];

const modules = [
  { 
    title: 'Dynamic Quote Builder',
    icon: Hammer,
    description: 'Customizable pricing tools with smart logic and dynamic calculations.'
  },
  { 
    title: 'Smart CRM',
    icon: Users,
    description: 'Auto-fill, tag, and track user behavior with AI-powered insights.'
  },
  { 
    title: 'Client Onboarding',
    icon: Cpu,
    description: 'Forms → logic → Slack/email integration for seamless onboarding.'
  },
  { 
    title: 'Internal Dashboard',
    icon: Zap,
    description: 'Control panel for daily workflows and operational metrics.'
  },
  { 
    title: 'PDF Parser',
    icon: FileText,
    description: 'Transform documents into structured, actionable data instantly.'
  },
  { 
    title: 'Auto-Learning FAQ',
    icon: Brain,
    description: 'Self-improving knowledge base built from team interactions.'
  },
];

const openVoiceflowAndTriggerIntent = (message: string) => {
  if (window.voiceflow?.chat?.open) {
    window.voiceflow.chat.open();
    setTimeout(() => {
      if (window.voiceflow?.chat?.sendMessage) {
        window.voiceflow.chat.sendMessage(message);
      }
    }, 1000); // Give the chat a moment to fully initialize
  } else {
    setTimeout(() => openVoiceflowAndTriggerIntent(message), 500);
  }
};

const handleScheduleCall = () => {
  openVoiceflowAndTriggerIntent('Book a Call');
};

const handleSeeHowItWorks = () => {
  openVoiceflowAndTriggerIntent('Show me how it works');
};

const handleLearnMore = (module: string) => {
  openVoiceflowAndTriggerIntent(`Tell me about ${module}`);
};

const NavBar = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-black/90 backdrop-blur-sm' : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <a href="#hero" className="text-xl font-bold flex items-center gap-2">
            <Hammer className="w-6 h-6 text-orange-500" />
            <span>Forge Protocol</span>
          </a>
          <div className="hidden md:flex space-x-1">
            <a href="#about" className="nav-item">About</a>
            <a href="#intro" className="nav-item">ForgeOS</a>
            <a href="#case-studies" className="nav-item">Case Studies</a>
            <a href="#modules" className="nav-item">Modules</a>
            <a href="#automation-scenario" className="nav-item">Scenario Builder</a>
            <a href="#quote-builder" className="nav-item">DQB</a>
            <button onClick={handleScheduleCall} className="nav-item">Contact</button>
          </div>
        </div>
      </div>
    </nav>
  );
};

const FadeInSection = ({ children }: { children: React.ReactNode }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.6 }}
    >
      {children}
    </motion.div>
  );
};

const ForgeModule = ({ title, icon: Icon, description }: { title: string; icon: React.ElementType; description: string }) => (
  <Link 
    to="/explore-modules"
    className="block"
  >
    <motion.div
      whileHover={{ scale: 1.05, y: -5 }}
      transition={{ duration: 0.3 }}
      className="p-8 rounded-xl border border-orange-500/20 hover:border-orange-500/40 
      bg-black/40 backdrop-blur-sm transition-all duration-300 relative group"
    >
      <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-orange-500/5 to-blue-500/5 
      group-hover:from-orange-500/10 group-hover:to-blue-500/10 transition-all duration-300" />
      <Icon className="w-10 h-10 text-orange-500 mb-4 relative" />
      <h3 className="text-2xl font-semibold mb-3 relative">{title}</h3>
      <p className="text-gray-400 mb-4 relative leading-relaxed">{description}</p>
      <div className="flex items-center gap-2 text-orange-400 group-hover:text-orange-300 
      transition-colors relative">
        Learn More <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
      </div>
      <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 
      transition-opacity duration-500 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-blue-500/20 
        blur-xl" />
      </div>
    </motion.div>
  </Link>
);

const ForgeModuleCard = ({ 
  title, 
  description, 
  tag, 
  icon: Icon 
}: { 
  title: string; 
  description: string; 
  tag: string; 
  icon: React.ElementType;
}) => (
  <Link
    to="/explore-modules"
    className="block"
  >
    <motion.div
      whileHover={{ scale: 1.02, y: -5 }}
      className="p-8 rounded-xl border border-blue-500/20 hover:border-blue-500/40 
      bg-black/40 backdrop-blur-sm transition-all duration-300 relative group min-w-[350px] snap-start"
    >
      <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-blue-500/5 to-blue-500/5 
      group-hover:from-blue-500/10 group-hover:to-blue-500/10 transition-all duration-300" />
      <div className="flex justify-between items-start mb-4">
        <Icon className="w-8 h-8 text-blue-500 relative" />
        <span className={`text-sm px-3 py-1 rounded-full relative ${
          tag === 'Frontend' ? 'bg-blue-500/20 text-blue-300' :
          tag === 'Backend' ? 'bg-purple-500/20 text-purple-300' :
          'bg-green-500/20 text-green-300'
        }`}>
          {tag}
        </span>
      </div>
      <h3 className="text-2xl font-semibold mb-3 relative">{title}</h3>
      <p className="text-gray-400 mb-4 relative leading-relaxed">{description}</p>
      <div className="flex items-center gap-2 text-blue-400 group-hover:text-blue-300 
      transition-colors relative">
        Learn More <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
      </div>
      <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 
      transition-opacity duration-500 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-blue-500/20 
        blur-xl rounded-xl" />
      </div>
    </motion.div>
  </Link>
);

const ForgeModuleCarousel = () => {
  const carouselRef = useRef<HTMLDivElement>(null);
  
  const scroll = (direction: 'left' | 'right') => {
    if (carouselRef.current) {
      const scrollAmount = direction === 'left' ? -400 : 400;
      carouselRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className="relative">
      <div className="absolute left-0 top-1/2 -translate-y-1/2 z-10">
        <button 
          onClick={() => scroll('left')}
          className="p-2 bg-black/50 rounded-full hover:bg-black/70 transition-colors border border-blue-500/30"
        >
          <ChevronLeft className="w-6 h-6 text-blue-400" />
        </button>
      </div>
      <div 
        ref={carouselRef}
        className="flex gap-6 overflow-x-auto px-12 pb-4 snap-x snap-mandatory hide-scrollbar"
      >
        {forgeModules.map((module, index) => (
          <ForgeModuleCard key={index} {...module} />
        ))}
      </div>
      <div className="absolute right-0 top-1/2 -translate-y-1/2 z-10">
        <button 
          onClick={() => scroll('right')}
          className="p-2 bg-black/50 rounded-full hover:bg-black/70 transition-colors border border-blue-500/30"
        >
          <ChevronRight className="w-6 h-6 text-blue-400" />
        </button>
      </div>
    </div>
  );
};

const UseCase = ({ title, description }: { title: string; description: string }) => (
  <motion.div
    whileHover={{ scale: 1.02, y: -5 }}
    className="p-8 rounded-lg border border-blue-500/20 hover:border-blue-500/40 transition-all duration-300 
    glow-blue bg-black/50 relative group cursor-pointer"
    onClick={() => handleLearnMore(title)}
  >
    <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-blue-500/5 
    group-hover:from-orange-500/10 group-hover:to-blue-500/10 rounded-lg transition-all duration-300" />
    <Lightning className="w-6 h-6 text-blue-400 mb-4" />
    <h3 className="text-2xl font-semibold mb-4 relative">{title}</h3>
    <p className="text-gray-300 mb-6 text-lg leading-relaxed relative">{description}</p>
    <a 
      href="#modules" 
      className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors font-medium relative"
    >
      See How <ArrowUpRight className="w-4 h-4" />
    </a>
    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
      <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-blue-500/10 rounded-lg blur-xl" />
    </div>
  </motion.div>
);

const ModuleCarousel = () => {
  const carouselRef = useRef<HTMLDivElement>(null);
  
  const scroll = (direction: 'left' | 'right') => {
    if (carouselRef.current) {
      const scrollAmount = direction === 'left' ? -400 : 400;
      carouselRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className="relative">
      <div className="absolute left-0 top-1/2 -translate-y-1/2 z-10">
        <button 
          onClick={() => scroll('left')}
          className="p-2 bg-black/50 rounded-full hover:bg-black/70 transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
      </div>
      <div 
        ref={carouselRef}
        className="module-carousel flex gap-6 overflow-x-auto px-12 pb-4 snap-x snap-mandatory"
      >
        {modules.map((module, index) => (
          <div key={index} className="min-w-[350px] snap-start">
            <ForgeModule {...module} />
          </div>
        ))}
      </div>
      <div className="absolute right-0 top-1/2 -translate-y-1/2 z-10">
        <button 
          onClick={() => scroll('right')}
          className="p-2 bg-black/50 rounded-full hover:bg-black/70 transition-colors"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

const StatCard = ({ value, label }: { value: string; label: string }) => (
  <motion.div
    whileHover={{ scale: 1.05 }}
    transition={{ duration: 0.5 }}
    className="hero-stat-card"
  >
    <div className="text-4xl font-bold mb-2 text-orange-500">{value}</div>
    <div className="text-gray-400">{label}</div>
  </motion.div>
);

const AutomationWizard = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    industry: '',
    role: '',
    email: '',
    phoneNumber: '',
    workflowDescription: '',
    consent: false
  });

  const handleNext = () => {
    if (step < 2) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    const element = document.getElementById('use-cases');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex justify-between mb-8">
        {[1, 2].map((num) => (
          <div
            key={num}
            className={`w-4 h-4 rounded-full ${
              step >= num ? 'bg-orange-500' : 'bg-gray-700'
            } transition-colors duration-300`}
          />
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="bg-black/30 backdrop-blur-sm rounded-xl p-8 border border-orange-500/20"
        >
          {step === 1 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-semibold mb-6">Tell us about your workflow</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-black/50 border border-orange-500/30 rounded-lg px-4 py-3 
                  text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50"
                  placeholder="Your full name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Industry
                </label>
                <input
                  type="text"
                  value={formData.industry}
                  onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                  className="w-full bg-black/50 border border-orange-500/30 rounded-lg px-4 py-3 
                  text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50"
                  placeholder="Your industry"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Role
                </label>
                <input
                  type="text"
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="w-full bg-black/50 border border-orange-500/30 rounded-lg px-4 py-3 
                  text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50"
                  placeholder="Your role"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Email (Optional)
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-black/50 border border-orange-500/30 rounded-lg px-4 py-3 
                  text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50"
                  placeholder="your@email.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Phone Number (Optional)
                </label>
                <input
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                  className="w-full bg-black/50 border border-orange-500/30 rounded-lg px-4 py-3 
                  text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50"
                  placeholder="+1 (555) 123-4567"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Brief description of workflow
                </label>
                <textarea
                  value={formData.workflowDescription}
                  onChange={(e) => setFormData({ ...formData, workflowDescription: e.target.value })}
                  className="w-full bg-black/50 border border-orange-500/30 rounded-lg px-4 py-3 
                  text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50 h-32"
                  placeholder="Describe your current workflow and what you'd like to automate..."
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 to-blue-500/10 rounded-lg" />
              <div className="relative p-6">
                <h3 className="text-2xl font-semibold mb-4">Your Automation Summary</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-orange-400">Name</h4>
                    <p className="text-gray-300">{formData.name || "Not provided"}</p>
                  </div>
                  <div>
                    <h4 className="text-orange-400">Industry</h4>
                    <p className="text-gray-300">{formData.industry || "Not specified"}</p>
                  </div>
                  <div>
                    <h4 className="text-orange-400">Role</h4>
                    <p className="text-gray-300">{formData.role || "Not specified"}</p>
                  </div>
                  <div>
                    <h4 className="text-orange-400">Workflow Description</h4>
                    <p className="text-gray-300">{formData.workflowDescription || "Not provided"}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-between mt-8">
            {step > 1 && (
              <button
                onClick={handleBack}
                className="px-6 py-2 text-gray-400 hover:text-white transition-colors"
              >
                Back
              </button>
            )}
            <button
              onClick={step === 2 ? handleSubmit : handleNext}
              className="ml-auto px-6 py-2 bg-orange-500 hover:bg-orange-600 rounded-lg transition-colors flex items-center gap-2"
            >
              {step === 2 ? 'Submit' : 'Continue'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

const CaseStudyCard = ({ 
  title, 
  description, 
  icon: Icon 
}: { 
  title: string; 
  description: string; 
  icon: React.ElementType;
}) => (
  <motion.div
    whileHover={{ scale: 1.02, y: -5 }}
    className="p-8 rounded-xl border border-orange-500/20 hover:border-orange-500/40 
    bg-black/40 backdrop-blur-sm transition-all duration-300 relative group cursor-pointer"
    onClick={() => handleLearnMore(title)}
  >
    <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-orange-500/5 to-blue-500/5 
    group-hover:from-orange-500/10 group-hover:to-blue-500/10 transition-all duration-300" />
    <Icon className="w-8 h-8 text-orange-500 mb-4 relative" />
    <h3 className="text-2xl font-semibold mb-3 relative">{title}</h3>
    <p className="text-gray-400 mb-4 relative leading-relaxed">{description}</p>
    <div className="flex items-center gap-2 text-orange-400 group-hover:text-orange-300 
    transition-colors relative">
      Build Similar <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
    </div>
    <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 
    transition-opacity duration-500 pointer-events-none">
      <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-blue-500/20 
      blur-xl rounded-xl" />
    </div>
  </motion.div>
);

const AboutPrinciple = ({ 
  icon, 
  title, 
  description 
}: { 
  icon: string; 
  title: string; 
  description: string;
}) => (
  <motion.div
    whileHover={{ scale: 1.02 }}
    className="flex items-start gap-4 p-4"
  >
    <span className="text-2xl">{icon}</span>
    <div>
      <h3 className="text-lg font-semibold mb-1 text-white">{title}</h3>
      <p className="text-gray-300 leading-relaxed">{description}</p>
    </div>
  </motion.div>
);

const Footer = () => {
  return (
    <footer className="footer-gradient py-24 border-t border-gray-800">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-6">Still exploring? Start a conversation.</h2>
            <motion.button 
              onClick={handleScheduleCall}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full font-semibold 
              transition-all duration-300 text-lg flex items-center gap-2 mx-auto hover:shadow-glow"
            >
              <MessageSquare className="w-5 h-5" />
              Talk to the System
            </motion.button>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12 items-start mb-12">
            <div>
              <h3 className="text-xl font-bold mb-4">Connect With Us</h3>
              <div className="flex flex-col gap-4">
                <a 
                  href="#"
                  onClick={handleScheduleCall}
                  className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors"
                >
                  <Calendar className="w-5 h-5" />
                  Schedule Call
                </a>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-4">Quick Links</h3>
              <div className="grid gap-2">
                <a href="#about" className="footer-link">About</a>
                <a href="#case-studies" className="footer-link">Case Studies</a>
                <a href="#modules" className="footer-link">ForgeOS</a>
                <a href="#modules" className="footer-link">Modules</a>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-4">Contact</h3>
              <div className="space-y-4">
                <div className="flex flex-col gap-2">
                  <a 
                    href="https://www.linkedin.com/in/faris-osmanbhoy-bb9227235"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="footer-contact-link"
                  >
                    <Linkedin className="w-5 h-5" />
                    LinkedIn
                  </a>
                  <a 
                    href="mailto:farisosmanbhoy01@gmail.com"
                    className="footer-contact-link"
                  >
                    <Mail className="w-5 h-5" />
                    Email
                  </a>
                </div>

                <div className="text-sm text-gray-400">
                  
                  <p className="font-semibold mb-2">Global Lines:</p>
                  <div className="space-y-2">
                    <p>USA (Call Only): <a href="tel:+18322193227" className="hover:text-white">+1 832 219 3227</a></p>
                    <p>UK/EU: 
                      <a href="tel:+447436352521" className="hover:text-white ml-1">+44 7436 352521</a>
                      <span className="mx-1">|</span>
                      <a href="https://wa.me/+447436352521" target="_blank" rel="noopener noreferrer" className="hover:text-white">WhatsApp</a>
                    </p>
                    <p>Singapore (WhatsApp Only): 
                      <a href="https://wa.me/+6597942604" target="_blank" rel="noopener noreferrer" className="hover:text-white ml-1">+65 9794 2604</a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <hr className="border-white/15 mb-8" />
            <p className="text-gray-400">© Forge Protocol 2025</p>
            <div className="flex justify-center gap-4 mt-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a>
              <span className="text-gray-600">•</span>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Terms & Conditions</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

const VisionSection = () => {
  return (
    <section className="vision-section py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0b0e13] to-[#150505]" />
      <div className="container mx-auto px-4 relative">
        <FadeInSection>
          <div className="max-w-4xl mx-auto">
            <h2 className="text-5xl font-bold mb-6 text-center hero-font glow">
              The Forge Protocol Vision
            </h2>
            
            <p className="text-xl text-center text-gray-300 mb-12 leading-relaxed">
              Forge Protocol isn't just automation. It's operational evolution — built for real businesses solving real-world problems.
            </p>

            <div className="h-px bg-white/15 w-full mb-12" />

            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-8 mb-12 border border-white/10">
              <p className="text-3xl text-center font-light text-white leading-relaxed">
                "Don't build faster chaos. Build smarter order."
              </p>
            </div>

            <div className="space-y-4 mb-12">
              <div className="flex items-start gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-2.5" />
                <p className="text-[#f0f0f0] text-lg">Replace repetition with structure</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-2.5" />
                <p className="text-[#f0f0f0] text-lg">Give teams visibility without extra overhead</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-2.5" />
                <p className="text-[#f0f0f0] text-lg">Adapt to how people actually work</p>
              </div>
            </div>

            <div className="text-center space-y-8">
              <p className="text-gray-300 text-lg">
                This isn't a beta. This isn't a deck.<br/>
                It's already live — and we're just getting started.
              </p>

              <p className="text-[#f0f0f0] text-lg font-semibold">
                Forge Protocol is not a pitch. It's a tested system — proven before ever being offered to others.
              </p>
            </div>
          </div>
        </FadeInSection>
      </div>
    </section>
  );
};

function App() {
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const glowIntensity = useTransform(scrollYProgress, [0, 0.1], [1, 1.5]);

  useEffect(() => {
    const updateBackgroundEffects = () => {
      const scroll = window.scrollY;
      const height = document.documentElement.scrollHeight - window.innerHeight;
      const progress = scroll / height;

      document.documentElement.style.setProperty('--grid-opacity', `${1 - progress * 0.7}`);
      document.documentElement.style.setProperty('--circuit-opacity', `${1 - progress * 0.5}`);
      document.documentElement.style.setProperty('--arc-opacity', `${progress * 0.8}`);
      document.documentElement.style.setProperty('--molten-opacity', `${progress * 0.3}`);
      document.documentElement.style.setProperty('--scroll-position', `${50 + progress * 50}%`);
      document.documentElement.style.setProperty('--line-opacity', `${0.05 + progress * 0.1}`);
    };

    window.addEventListener('scroll', updateBackgroundEffects);
    updateBackgroundEffects();

    return () => window.removeEventListener('scroll', updateBackgroundEffects);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="forge-background" />
      <div className="forge-lines" />
      <div className="electric-arcs" />
      <div className="molten-glow" />
      <NavBar />
      
      <section id="hero" className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 hero-grid" />
        <div className="absolute inset-0 hero-circuit" />
        <motion.div 
          className="absolute inset-0 hero-glow"
          style={{ opacity: glowIntensity }}
        />
        <div className="container mx-auto px-4 text-center relative z-10 py-20">
          <motion.h1 
            initial={{opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="hero-title mb-8"
          >
            <span>Forge</span> Protocol
          </motion.h1>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-3xl mx-auto space-y-4 mb-12"
          >
            <p className="hero-tagline">
              Operate sharper. Scale smarter.
            </p>
            <p className="text-xl text-gray-400 tracking-wider">
              Strategy. Systems. Execution.
            </p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y:  0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col md:flex-row gap-6 justify-center items-center mb-16"
          >
            <motion.button
              onClick={handleScheduleCall}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="hero-button hero-button-primary flex items-center gap-2 min-w-[200px] justify-center"
            >
              Book a Call
              <PhoneCall className="w-5 h-5" />
            </motion.button>
            <motion.button
              onClick={handleSeeHowItWorks}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="hero-button hero-button-secondary flex items-center gap-2 min-w-[200px] justify-center"
            >
              See How It Works
              <ChevronDown className="w-5 h-5" />
            </motion.button>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              duration: 0.8, 
              delay: 0.6,
              type: "spring",
              stiffness: 100 
            }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto"
          
          >
            <StatCard value="500+" label="Businesses Automated" />
            <StatCard value="95%" label="Time Saved" />
            <StatCard value="24/7" label="AI Operations" />
          </motion.div>
        </div>
      </section>

      <section id="about" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 circuit-grid opacity-20" />
        <div className="absolute inset-0 circuit-veins" />
        <div className="container mx-auto px-4 relative">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <FadeInSection>
              <div className="space-y-6">
                <h2 className="text-5xl font-bold hero-font glow mb-4">About Forge Protocol</h2>
                <p className="text-xl text-orange-400 italic mb-6">
                  We're not just building tools — we're forging operators.
                </p>
                <div className="space-y-6 text-lg text-gray-300">
                  <p>
                    Forge Protocol helps founders and teams scale intelligently — not by adding more apps or headcount, 
                    but by designing systems that think for themselves.
                  </p>
                  <p>
                    We replace scattered tools and repetitive tasks with modular, AI-powered automation that adapts, 
                    evolves, and executes. From solo operators to scaling companies, we empower lean teams to run 
                    like full-stack enterprises.
                  </p>
                  <p>
                    This isn't about flashy dashboards — it's about deep operational structure.<br/>
                    It's about unlocking growth without adding bulk.
                  </p>
                  <p className="text-orange-400 italic font-medium">
                    Built to scale. Designed to connect. Ready to think.<br/>
                    This is the Forge Protocol.
                  </p>
                </div>
              </div>
            </FadeInSection>

            <FadeInSection>
              <motion.div
                whileHover={{ scale: 1.02 }}
                className="relative p-8 rounded-2xl border border-orange-500/20 
                bg-black/40 backdrop-blur-lg overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 to-blue-500/10 rounded-2xl" />
                <div className="absolute inset-0 bg-gradient-to-tr from-orange-500/5 via-transparent to-blue-500/5" />
                
                <div className="relative">
                  <h3 className="text-2xl font-semibold mb-8 text-center">
                    Our Core Operating Principles
                  </h3>
                  <div className="space-y-6">
                    <AboutPrinciple
                      icon="⚡"
                      title="Rapid Implementation"
                      description="Get up and running in days, not months."
                    />
                    <AboutPrinciple
                      icon="🧩"
                      title="Custom Integration"
                      description="Seamlessly connects to what you already use — no rip and replace."
                    />
                    <AboutPrinciple
                      icon="🔐"
                      title="Enterprise-Ready"
                      description="Built to scale securely — startup speed, enterprise strength."
                    />
                  </div>
                </div>

                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 
                transition-opacity duration-500 pointer-events-none">
                  <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-blue-500/20 
                  blur-xl rounded-2xl" />
                </div>
              </motion.div>
            </FadeInSection>
          </div>
        </div>
      </section>

      <section id="intro" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 circuit-grid opacity-30" />
        <div className="absolute inset-0 circuit-veins" />
        
        <div className="container mx-auto px-4 relative">
          <FadeInSection>
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-4 hero-font glow">ForgeOS</h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
                The modular automation system powering smarter, faster companies.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
              {modules.map((module, index) => (
                <ForgeModule key={index} {...module} />
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <motion.button
                onClick={handleScheduleCall}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="hero-button hero-button-primary"
              >
                Schedule a Consult
              </motion.button>
              <motion.a
                href="#scenario-builder"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="hero-button hero-button-secondary"
              >
                Try Scenario Builder
              </motion.a>
            </div>
          </FadeInSection>
        </div>
      </section>

      <section id="case-studies" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 circuit-grid opacity-20" />
        <div className="absolute inset-0 circuit-veins" />
        <div className="container mx-auto px-4 relative">
          <FadeInSection>
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-4 hero-font glow">Real-World Wins</h2>
              <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
                These aren't just projects. They're proof that smart systems scale better — and Forge Protocol knows how to build them.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {caseStudies.map((study, index) => (
                <CaseStudyCard key={index} {...study} />
              ))}
            </div>
          </FadeInSection>
        </div>
      </section>

      <section id="modules" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 circuit-grid opacity-20" />
        <div className="absolute inset-0 circuit-veins" />
        <div className="container mx-auto px-4 relative">
          <FadeInSection>
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-4 hero-font glow">Inside ForgeOS</h2>
              <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed mb-2">
                Not just features — modular intelligence. Explore the 40+ automation systems shaping smarter operations from every angle.
              </p>
              <p className="text-lg text-blue-400 italic">
                Built to scale. Designed to connect. Ready to think.
              </p>
            </div>
            <ForgeModuleCarousel />
          </FadeInSection>
        </div>
      </section>

      <section id="automation-scenario" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 circuit-grid opacity-20" />
        <div className="absolute inset-0 circuit-veins" />
        <div className="container mx-auto px-4 relative">
          <FadeInSection>
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-4 hero-font glow">Discover Your Automation Scenario</h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
                Tell us how you work — we'll show you what we can automate.
              </p>
            </div>
            <AutomationWizard />
          </FadeInSection>
        </div>
      </section>

      <section id="quote-builder" className="py-24">
        <div className="container mx-auto px-4">
          <FadeInSection>
            <div className="border border-orange-500/20 rounded-2xl p-16 text-center glow-orange bg-black/50 max-w-4xl mx-auto">
              <h2 className="text-4xl font-bold mb-6 glow">Need a Quote?</h2>
              <p className="text-xl text-gray-300 mb-12">
                Use our interactive builder to get a price estimate in minutes — no meetings needed. 
                Everything is modular. Everything is smart.
              </p>
              <div className="bg-black/30 p-12 rounded-lg mb-12 border border-orange-500/10">
                <p className="text-2xl text-gradient font-semibold">Dynamic Quote Builder Coming Soon</p>
              </div>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 text-lg"
              >
                Build Your Quote
              </motion.button>
            </div>
          </FadeInSection>
        </div>
      </section>

      <VisionSection />

      <Footer />
    </div>
  );
}

export default App;